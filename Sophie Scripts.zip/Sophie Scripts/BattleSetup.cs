using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.SceneManagement;
using UnityEngine.UI;
/*
 *  Author: Sophie Toon 
 *  Purpose: Sets up characters in battle scene and runs end game menu
 */

public enum BattleState { START, BATTLE, END};

public class BattleSetup : MonoBehaviour
{
    public GameObject gameManager, postBattleMenu, p1WinTxt, p2WinTxt, p1Charge, p2Charge;
    public GameObject[] wands;
    public Transform player1Station, player2Station;
    public BattleState state;

    // Start is called before the first frame update
    void Start()
    {
        GameObject.FindObjectOfType<BattleDirector>().tutorialMode = false; //Makes sure that Battle Director isn't currently in tutorial mode
        postBattleMenu.SetActive(false);
        gameManager = GameObject.FindGameObjectWithTag("GameManager");
        GameObject player1GO = Instantiate(gameManager.GetComponent<GameManager>().player1, player1Station);
        player1GO.tag = "Player1";
        GameObject player2GO = Instantiate(gameManager.GetComponent<GameManager>().player2, player2Station);
        player2GO.tag = "Player2";
        player2GO.transform.rotation = Quaternion.Euler(0, 180, 0);
        state = BattleState.BATTLE;
    }

    private void Update()
    {
        if (state == BattleState.END)
        {
            if (Input.GetButtonDown("P1Button1") || Input.GetButtonDown("P2Button1")) // Restart Battle
            {
                postBattleMenu.SetActive(false);
                SceneManager.LoadScene("Battle scene");
            }
            if (Input.GetButtonDown("P1Button2") || Input.GetButtonDown("P2Button2")) // Go back to character select
            {
                SceneManager.LoadScene("Character Select");
            }
            if (Input.GetButtonDown("P1Button3") || Input.GetButtonDown("P2Button3")) // Go to main menu
            {
                SceneManager.LoadScene("Main Menu");
            }
        }
    }
}
