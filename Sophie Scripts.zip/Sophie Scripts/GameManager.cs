using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.SceneManagement;

/*
 *  Author: Sophie Toon 
 *  Purpose: Game manager that brings things like character selection choices, 
 *  and player sensitivty to other scenes. Also has a reset if left alone for too long.
 */

public class GameManager : MonoBehaviour
{
	
	public GameObject player1, player2;
	public GameObject[] playerPrefabs, gingerPrefabs, naeniaPrefabs, wormolPrefabs;
	public int stageSelect = 0;
	[Space]
	public float player1Sensitivity;
	public float player2Sensitivity;
	private float gameTimer = 0;

	// add sensitivity setting val to each player

	private void Awake()
	{
		QualitySettings.vSyncCount = 1;

		GameObject[] objs = GameObject.FindGameObjectsWithTag("GameManager");

		if (objs.Length > 1)
		{
			Destroy(this.gameObject);
		}

		DontDestroyOnLoad(this.gameObject);
	}

	public void Player1Select(int character, int color) 
	{
		if (character == 0) 
		{
			player1 = gingerPrefabs[color];
		}
		if (character == 1)
		{
			player1 = naeniaPrefabs[color];
		}
		if (character == 2)
		{
			player1 = wormolPrefabs[color];
		}
	}

	public void Player2Select(int character, int color)
	{
		if (character == 0)
		{
			player2 = gingerPrefabs[color];
		}
		if (character == 1)
		{
			player2 = naeniaPrefabs[color];
		}
		if (character == 2)
		{
			player2 = wormolPrefabs[color];
		}
	}
    // Track what character is selected for both player one and player two so scripts can refrence them in battle scene

    private void FixedUpdate()
    {
		if ( gameTimer == 3600 ) 
		{
			gameTimer = 0;
			SceneManager.LoadScene("Main Menu");
		}
        else
        {
			gameTimer++;
        }

		if (Input.anyKey) 
		{
			gameTimer = 0;
		}
    }

}
