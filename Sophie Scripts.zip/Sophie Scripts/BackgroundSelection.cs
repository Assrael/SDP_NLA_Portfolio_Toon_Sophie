using System.Collections;
using System.Collections.Generic;
using UnityEngine;

/*
 *  Author: Sophie Toon 
 *  Purpose: Sets up background in battle scene.
 */

public class BackgroundSelection : MonoBehaviour
{
    public GameObject[] background;
    private GameObject gameManager;

    // Start is called before the first frame update
    void Start()
    {
        gameManager = GameObject.FindGameObjectWithTag("GameManager");
        background[gameManager.GetComponent<GameManager>().stageSelect].SetActive(true);   
    }

}
