using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.SceneManagement;
using UnityEngine.UI;
/*
 *  Author: Sophie Toon & Nevin Portillo
 *  Purpose: Sets up and runs the tutorial for the game
 */
public enum TutorialState { START, UI, WANDFUNCTION, SIMULATION, END };


public class Tutorial : MonoBehaviour
{
    public TutorialState state;

    //***** TUTORIAL OBJECT REFERENCES *****
    public GameObject startPanel; //Reference to starting panel for tutorial
    public GameObject uiPanel; //Reference to panel we'll use to show off each ui element
    public GameObject wandFunctionPanel; //Reference to panel showing off the parts of a wand and how it generally works
    public GameObject endMenu;
    [Space]
    public Text tutorialText; //Reference to the text that will guide the players
    public Text skipTutorialText; //Reference to the text that will stay visible to tell players they can skip
    [Space]
    public GameObject opacityPanel; //Used to "lower opacity" for the background by just bringing up a slightly transparent panel in front of it
    [Space]
    public GameObject[] tutorialArray = new GameObject[4];
    [Space]
    public GameObject tutorialQrow;

    // Character shit
    public GameObject gameManager;
    public Transform player1Station, player2Station;

    //*** Private ***
    float delayTimer; //Timer in charge of having a delay between parts of tutorial so players don't accidentally instant-skip
    float delayTimerReset;

    [HideInInspector] public int tutorialTextInt; //Int to progress through different tutorial texts

    void Start()
    {
        delayTimer = 1.5f;
        delayTimerReset = delayTimer;

        startPanel.SetActive(true);

        uiPanel.SetActive(false);
        wandFunctionPanel.SetActive(false);
        endMenu.SetActive(false);

        GameObject.FindObjectOfType<BattleDirector>().tutorialMode = true; //There will be a Battle Director in the tutorial scene with the same script, but in tutorial mode
        
        //character instantiate
        gameManager = GameObject.FindGameObjectWithTag("GameManager");
        GameObject player1GO = Instantiate(gameManager.GetComponent<GameManager>().player1, player1Station);
        player1GO.tag = "Player1";
        GameObject player2GO = Instantiate(gameManager.GetComponent<GameManager>().player2, player2Station);
        player2GO.tag = "Player2";
        player2GO.transform.rotation = Quaternion.Euler(0, 180, 0);
        //end

        state = TutorialState.START;

    }

    void Update()
    {
        TutorialStateFunction();

        //Skipping tutorial
        if (state != TutorialState.END) //If the tutorial hasn't ended yet
        {
            //Gameobject or UI text should appear at all times to tell players what button to press to skip tutorial
            if (tutorialTextInt != 3) //If in the simulation phase the tutorial hasn't reached the last bit of text
            {
                if (Input.GetButtonDown("P1Button3") || Input.GetButtonDown("P2Button3")) //If the players press the bottom buttons
                {
                    //Making sure all panels (except for end menu) get turned off since tutorial can be skipped at any part of it
                    startPanel.SetActive(false);
                    uiPanel.SetActive(false);
                    wandFunctionPanel.SetActive(false);
                    endMenu.SetActive(true);

                    state = TutorialState.END; //End the tutorial
                }
            }
        }
    }

    void TutorialStateFunction()
    {
        switch (state)
        {
            case TutorialState.START: //Very start of tutorial !!!!! Can be deleted if it's unnecessary and drags the tutorial to be longer !!!!!

                tutorialText.text = " ";
                delayTimer -= Time.deltaTime; //Delay Timer starts going down

                if (delayTimer <= 0) //Once delay timer ends, let players know (and allow them) to press a button to continue, moving them on to the UI part of the tutorial
                {
                    tutorialText.text = "(Press the 'Up' button to continue)";

                    if (Input.GetButtonDown("P1Button1") || Input.GetButtonDown("P2Button1"))
                    {
                        startPanel.SetActive(false);
                        uiPanel.SetActive(true);

                        tutorialTextInt = 0;
                        delayTimer = delayTimerReset;
                        state = TutorialState.UI;
                    }
                }

                break;
            case TutorialState.UI: //Tutorial introducing UI elements
                
                tutorialText.text = " ";
                delayTimer -= Time.deltaTime; //Delay Timer starts going down

                //"UI" part of tutorial functions go here
                opacityPanel.SetActive(true);

                tutorialArray[tutorialTextInt].SetActive(true);

                if (tutorialTextInt == 1)
                {
                    GameObject.FindObjectOfType<BattleDirector>().P1PowerMeterBar.value = 100f;
                    GameObject.FindObjectOfType<BattleDirector>().P2PowerMeterBar.value = 100f;
                }
                else
                {
                    GameObject.FindObjectOfType<BattleDirector>().P1PowerMeterBar.value = 0f;
                    GameObject.FindObjectOfType<BattleDirector>().P2PowerMeterBar.value = 0f;
                }

                if (delayTimer <= 0) //Once delay timer ends, let players know (and allow them) to press a button to continue, moving them on to the Wand Function part of the tutorial
                {
                    tutorialText.text = "(Press the 'Up' button to continue)";

                    if (Input.GetButtonDown("P1Button1") || Input.GetButtonDown("P2Button1"))
                    {
                        if (tutorialTextInt < 2)
                        {
                            tutorialArray[tutorialTextInt].SetActive(false);
                            tutorialTextInt++;
                            delayTimer = delayTimerReset;
                        }
                        else if (tutorialTextInt == 2)
                        {
                            uiPanel.SetActive(false);
                            wandFunctionPanel.SetActive(true);
                            tutorialQrow.SetActive(false);
                            delayTimer = delayTimerReset;
                            state = TutorialState.WANDFUNCTION;
                        }
                    }
                }

                break;
            case TutorialState.WANDFUNCTION: //Tutorial introducing wand anatomy and function

                tutorialText.text = " ";
                delayTimer -= Time.deltaTime; //Delay Timer starts going down

                //"Wand Function" part of tutorial functions go here
                opacityPanel.SetActive(false);

                if (delayTimer <= 0) //Once delay timer ends, let players know (and allow them) to press a button to continue, moving them on to the Simulation part of the tutorial
                {
                    tutorialText.text = "(Press the 'Up' button to continue)";

                    if (Input.GetButtonDown("P1Button1") || Input.GetButtonDown("P2Button1"))
                    {
                        wandFunctionPanel.SetActive(false);

                        tutorialTextInt = 1;
                        delayTimerReset = 1.5f; //Probably want to change delay timer to be shorter for simulation phase regarding the text
                        delayTimer = 0; //Players can instantly move on from next text without delay
                        tutorialQrow.SetActive(false);
                        state = TutorialState.SIMULATION;
                    }
                }

                break;
            case TutorialState.SIMULATION: //Tutorial having players run through simulation

                if (tutorialTextInt == 1) //Preparation of simulation
                {
                    tutorialText.text = "Okay! Are both player's ready to practice? (Press the 'Up' button to continue)";
                }
                else if (tutorialTextInt == 2) //Tutorial will give control to the Battle Director so players can go through one run of spell casting
                {
                    //Tutorial text follows the same text as set by the Battle Director
                    //Delay timer will not be going down since players will now follow the timing of the Battle Director
                }
                else if (tutorialTextInt == 3) //Ending of tutorial guiding players
                {
                    tutorialArray[3].SetActive(true);
                    tutorialText.text = "(Press the 'Up' button to continue)";
                    skipTutorialText.text = " ";
                    tutorialQrow.SetActive(true);
                    delayTimer -= Time.deltaTime; //Delay timer to progress simulation
                }
                
                //Removed freeplay, tutorial will end once players do a single round of casting

                if (delayTimer <= 0)
                {
                    if (Input.GetButtonDown("P1Button1") || Input.GetButtonDown("P2Button1"))
                    {
                        if (tutorialTextInt == 1) //If the players are not at the end of the simulation part of the tutorial
                            tutorialTextInt++; //Continue progressing after each text
                        else if (tutorialTextInt == 3) //Otherwise, if the players are at the end of the simulation part of the tutorial
                        {
                            endMenu.SetActive(true);
                            tutorialQrow.SetActive(false);
                            tutorialArray[3].SetActive(false);
                            state = TutorialState.END; //End the tutorial
                        }
                    }
                }

                break;
            case TutorialState.END: //End of tutorial

                tutorialText.text = " ";

                if (Input.GetButtonDown("P1Button1") || Input.GetButtonDown("P2Button1"))
                {
                    Debug.Log("Play Game!");
                    StartCoroutine(GameStart());
                }
                else if (Input.GetButtonDown("P1Button2") || Input.GetButtonDown("P2Button2"))
                {
                    Debug.Log("Restart Tutorial");
                    //StartCoroutine(StartTutorial());

                    SceneManager.LoadScene("Tutorial Scene"); //!!!!! Temporary !!!!!
                }
                else if (Input.GetButtonDown("P1Button3") || Input.GetButtonDown("P2Button3"))
                {
                    Debug.Log("Back To Main Menu");
                    StartCoroutine(ToMainMenu());
                }

                break;
        }
    }

    IEnumerator GameStart()
    {
        yield return new WaitForSeconds(1f);
        endMenu.SetActive(false);
        SceneManager.LoadScene("Character Select");
    }

    IEnumerator ToMainMenu()
    {
        yield return new WaitForSeconds(1f);
        endMenu.SetActive(false);
        SceneManager.LoadScene("Main Menu");
    }
}
