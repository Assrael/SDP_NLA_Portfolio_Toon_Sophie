using System.Collections;
using System.Collections.Generic;
using UnityEngine;

/*
 *  Author: Sophie Toon 
 *  Purpose: The currently used version of the character stats
 *  Differences are on each prefab. 
 */

public class CharacterAttributes : MonoBehaviour
{
    public string unitName;

    [Header("Stats")]
    public float maxHealth;
    public float health;
    public float chargeRate;
    public float damageMultipler;

}
