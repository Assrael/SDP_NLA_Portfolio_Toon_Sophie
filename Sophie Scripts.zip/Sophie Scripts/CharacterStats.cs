using UnityEngine;

/*
 *  Author: Sophie Toon 
 *  Purpose: Prototype for SO version of characters. Not used.
 */

[CreateAssetMenu(fileName = "Data", menuName = "ScriptableObjects/CharacterStats", order = 1)]
public class CharacterStats : ScriptableObject
{
    public string unitName;

    [Header("Stats")]
    public float maxHealth;
    public float health;
    public float chargeRate;
    public float damageMultipler;
}
