using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.SceneManagement;

/*
 *  Author: Sophie Toon 
 *  Purpose: Main menu control
 */

public enum Menu { START, MENU, PLAY, DEMO, OPTIONS };

public class StartGame : MonoBehaviour
{
    public GameObject[] menuElements;

    public Menu state;

    private void Start()
    {
        menuElements[0].SetActive(true);
        menuElements[1].SetActive(false);
        menuElements[2].SetActive(false);
        state = Menu.START;
    }

    void Update()
    {
        if (state == Menu.START)
        {
            if (Input.anyKeyDown) 
            {
                StartCoroutine(StartMenu());
            }
        }
        if (state == Menu.MENU)
        {
            if (Input.GetButtonDown("P1Button1") || Input.GetButtonDown("P2Button1"))
            {
                Debug.Log("Play Game!");
                StartCoroutine(GameStart());
            }
            else if (Input.GetButtonDown("P1Button2") || Input.GetButtonDown("P2Button2"))
            {
                Debug.Log("Tutorial");
                StartCoroutine(StartTutorial());
            }
            else if (Input.GetButtonDown("P1Button3") || Input.GetButtonDown("P2Button3"))
            {
                Debug.Log("Settings");
                StartCoroutine(ShowOptions());
            }
        }
        if (state == Menu.OPTIONS) 
        {
            Sensitivity sensitivity = GameObject.FindObjectOfType<Sensitivity>();

            //If both player have set their sensitivity, send sensitivity value to GameManager then go back to the start menu
            if (sensitivity.player1SensitivityReady == true && sensitivity.player2SensitivityReady == true)
            {
                GameObject.FindObjectOfType<GameManager>().player1Sensitivity = sensitivity.player1SensitivityValue;
                GameObject.FindObjectOfType<GameManager>().player2Sensitivity = sensitivity.player2SensitivityValue;

                StartCoroutine(StartMenu());
            }
        }
    }

    IEnumerator StartMenu() 
    {
        yield return new WaitForSeconds(.5f);
        menuElements[0].SetActive(false); // hide start screen
        menuElements[1].SetActive(true); // show main menu
        menuElements[2].SetActive(false); // hide options if coming back from option menu
        state = Menu.MENU;
    }

    IEnumerator GameStart()
    {
        yield return new WaitForSeconds(.5f);
        menuElements[1].SetActive(false);
        state = Menu.PLAY;
        SceneManager.LoadScene("Character Select");
    }

    IEnumerator StartTutorial()
    {
        yield return new WaitForSeconds(.5f);
        menuElements[1].SetActive(false);
        state = Menu.DEMO;
        SceneManager.LoadScene("Tutorial Scene");
    }

    IEnumerator ShowOptions()
    {
        yield return new WaitForSeconds(.5f);
        menuElements[1].SetActive(false);
        menuElements[2].SetActive(true);
        state = Menu.OPTIONS;
    }
}
