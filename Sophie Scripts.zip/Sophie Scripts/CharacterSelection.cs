using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.SceneManagement;

/*
 *  Author: Sophie Toon 
 *  Purpose: Sets up and runs the character select, color select, and background select.
 */

public enum CCState { CHARACTER, COLOR, STAGE, END };

public class CharacterSelection : MonoBehaviour
{
    public GameObject[] characters, menus;
    public GameObject selectionP1, selectionP2, gameManager;
    public SpriteRenderer stageView;
    public SpriteRenderer[] p1Color, p2Color;
    public Sprite[] gingerColor, naeniaColor, wormolColor, stageImage;
    private int pos1, pos2, player1Color, player2Color, stage;
    private bool player1Select, player2Select, color1Select, color2Select, stageSelect = false;
    public CCState state;

    private void Awake()
    {
        menus[0].SetActive(true);
        menus[1].SetActive(false);
        menus[3].SetActive(false);
        pos1 = 0;
        pos2 = 2;
        stage = 0;
        selectionP1.transform.position = new Vector3(characters[pos1].transform.position.x, characters[pos1].transform.position.y, 0);
        selectionP2.transform.position = new Vector3(characters[pos2].transform.position.x, characters[pos2].transform.position.y, 0);
        gameManager = GameObject.FindGameObjectWithTag("GameManager");
        state = CCState.CHARACTER;
    }

    void Update()
    {   
        if (state == CCState.CHARACTER) 
        {
            if (player1Select == false)
            {
                if (Input.GetButtonDown("P1Button1") && pos1 > 0) // go left
                {
                    pos1 -= 1;
                    selectionP1.transform.position = new Vector3(characters[pos1].transform.position.x, characters[pos1].transform.position.y, 0);
                }
                if (Input.GetButtonDown("P1Button3") && pos1 < characters.Length - 1) // go right
                {
                    pos1 += 1;
                    selectionP1.transform.position = new Vector3(characters[pos1].transform.position.x, characters[pos1].transform.position.y, 0);
                }
                if (Input.GetButtonDown("P1Button2")) // select
                {
                    Debug.Log("character P1 selected!");
                    player1Select = true;
                    //gameManager.GetComponent<GameManager>().Player1Select(pos1);
                }
            }
            if (player2Select == false)
            {
                if (Input.GetButtonDown("P2Button1") && pos2 > 0) // go left
                {
                    pos2 -= 1;
                    selectionP2.transform.position = new Vector3(characters[pos2].transform.position.x, characters[pos2].transform.position.y, 0);
                }
                if (Input.GetButtonDown("P2Button3") && pos2 < characters.Length - 1) // go right
                {
                    pos2 += 1;
                    selectionP2.transform.position = new Vector3(characters[pos2].transform.position.x, characters[pos2].transform.position.y, 0);
                }
                if (Input.GetButtonDown("P2Button2")) // select
                {
                    Debug.Log("character P2 selected!");
                    player2Select = true;
                    //gameManager.GetComponent<GameManager>().Player2Select(pos2);
                }

            }
            if (player1Select == true && player2Select == true)
            {
                menus[0].SetActive(false);
                menus[1].SetActive(true);
                //  Player one color display
                if (pos1 == 0)  //  Ginger
                {
                    p1Color[0].sprite = gingerColor[0];
                    p1Color[1].sprite = gingerColor[1];
                    p1Color[2].sprite = gingerColor[2];
                }
                else if (pos1 == 1) //  Naenia
                {
                    p1Color[0].sprite = naeniaColor[0];
                    p1Color[1].sprite = naeniaColor[1];
                    p1Color[2].sprite = naeniaColor[2];
                }
                else if (pos1 == 2) //  Wormol
                {
                    p1Color[0].sprite = wormolColor[0];
                    p1Color[1].sprite = wormolColor[1];
                    p1Color[2].sprite = wormolColor[2];
                }
                //  Player two color display
                if (pos2 == 0)  //  Ginger
                {
                    p2Color[0].sprite = gingerColor[0];
                    p2Color[1].sprite = gingerColor[1];
                    p2Color[2].sprite = gingerColor[2];
                }
                else if (pos2 == 1) //  Naenia
                {
                    p2Color[0].sprite = naeniaColor[0];
                    p2Color[1].sprite = naeniaColor[1];
                    p2Color[2].sprite = naeniaColor[2];
                }
                else if (pos2 == 2) //  Wormol
                {
                    p2Color[0].sprite = wormolColor[0];
                    p2Color[1].sprite = wormolColor[1];
                    p2Color[2].sprite = wormolColor[2];
                }

                StartCoroutine(WaitCharacter());
                
            }
        }

        if (state == CCState.COLOR)
        {
            if (color1Select == false)
            {
                if (Input.GetButtonDown("P1Button1"))
                {
                    player1Color = 0;
                    color1Select = true;
                    Debug.Log("P1 color selected!");
                }
                if (Input.GetButtonDown("P1Button2"))
                {
                    player1Color = 1;
                    color1Select = true;
                    Debug.Log("P1 color selected!");
                }
                if (Input.GetButtonDown("P1Button3"))
                {
                    player1Color = 2;
                    color1Select = true;
                    Debug.Log("P1 color selected!");
                }
            }
            if (color2Select == false)
            {
                if (Input.GetButtonDown("P2Button1"))
                {
                    player2Color = 0;
                    color2Select = true;
                    Debug.Log("P2 color selected!");
                }
                if (Input.GetButtonDown("P2Button2"))
                {
                    player2Color = 1;
                    color2Select = true;
                    Debug.Log("P2 color selected!");
                }
                if (Input.GetButtonDown("P2Button3"))
                {
                    player2Color = 2;
                    color2Select = true;
                    Debug.Log("P2 color selected!");
                }
            }
            if (color1Select && color2Select)
            {
                CharacterSelect(pos1, player1Color, pos2, player2Color);
                menus[2].SetActive(false);
                menus[3].SetActive(true);
                StartCoroutine(WaitColor());
            }

        }

        if (state == CCState.STAGE)
        {
            if (stageSelect == false) {
                if (Input.GetButtonDown("P1Button1") && stage > 0) // go left
                {
                    stage -= 1;
                    stageView.sprite = stageImage[stage];
                    StartCoroutine(WaitStageSelect());
                }
                else if (Input.GetButtonDown("P1Button1") && stage == 0)
                {
                    stage = stageImage.Length - 1;
                    stageView.sprite = stageImage[stage];
                    StartCoroutine(WaitStageSelect());
                }
                if (Input.GetButtonDown("P1Button3") && stage < stageImage.Length - 1) // go right
                {
                    stage += 1;
                    stageView.sprite = stageImage[stage];
                    StartCoroutine(WaitStageSelect());
                }
                else if (Input.GetButtonDown("P1Button3") && stage == stageImage.Length - 1) // go right
                {
                    stage = 0;
                    stageView.sprite = stageImage[stage];
                    StartCoroutine(WaitStageSelect());
                }
                if (Input.GetButtonDown("P1Button2")) // select
                {
                    Debug.Log("character P1 selected!");
                    stageSelect = true;
                }
            }
            if (stageSelect == true) 
            {
                gameManager.GetComponent<GameManager>().stageSelect = stage;
                StartCoroutine(WaitStage());
                
            }
        }

    }
    IEnumerator WaitCharacter()
    {
        yield return new WaitForSeconds(.5f);
        state = CCState.COLOR;
    }
    IEnumerator WaitColor()
    {
        yield return new WaitForSeconds(.5f);
        state = CCState.STAGE;
    }
    IEnumerator WaitStage()
    {
        yield return new WaitForSeconds(.5f);
        SceneManager.LoadScene("Battle scene");
    }
    IEnumerator WaitStageSelect() 
    {
        yield return new WaitForSeconds(.1f);
    }
    public void CharacterSelect(int character1, int color1, int character2, int color2) 
    {
        ColorChecker();
        gameManager.GetComponent<GameManager>().Player1Select(character1, color1);
        gameManager.GetComponent<GameManager>().Player2Select(character2, color2);
    } //sets the characters and colors in the game manager
    public void ColorChecker() //makes sure players who choose the same character and color don't have the same color
    {
        if (pos1 == pos2 && player1Color == player2Color)
        {
            if (player1Color == 0)
            {
                player2Color = 1;
                return;
            }
            else 
            {
                player2Color = 0;
                return;
            }
        }
        else 
        {
            return;
        }
    }
}
